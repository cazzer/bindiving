(function(){"use strict";function w(e,t){const{onStatus:n,onVerdict:r,onResult:a,onError:d}=t;return new Promise(o=>{n==null||n("Diving in...");const c=chrome.runtime.connect({name:"bindiving"});c.postMessage({type:"evaluate",product:e}),c.onMessage.addListener(s=>{s.type==="status"&&(n==null||n(s.message)),s.type==="verdict"&&(r==null||r(s.data)),s.type==="result"&&(a==null||a(s.data),o()),s.type==="error"&&(d==null||d(s.error),o())}),c.onDisconnect.addListener(()=>o())})}function m(e){return new Promise(t=>{const n=chrome.runtime.connect({name:"bindiving"});n.postMessage({type:"resolve",product:e,index:0}),n.onMessage.addListener(r=>{r.type==="resolved"&&(t(r.data),n.disconnect())}),n.onDisconnect.addListener(()=>t(null))})}const $=`
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;800&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,700;1,9..144,400&display=swap');

:host {
  all: initial;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  color: #e8e4dc;
  font-size: 13px;
  line-height: 1.5;
}

#bd-panel {
  position: fixed;
  top: 16px;
  right: 16px;
  width: 360px;
  max-height: calc(100vh - 32px);
  overflow-y: auto;
  z-index: 2147483647;
  border-radius: 16px;
  background: rgba(26, 24, 20, 0.85);
  border: 1px solid rgba(61, 56, 50, 0.5);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(43, 220, 210, 0.05);
  opacity: 0;
  transform: translateY(-8px) scale(0.98);
  pointer-events: none;
  transition: opacity 0.2s ease, transform 0.2s ease;
}

#bd-panel.bd-visible {
  opacity: 1;
  transform: translateY(0) scale(1);
  pointer-events: auto;
}

/* Scrollbar */
#bd-panel::-webkit-scrollbar { width: 4px; }
#bd-panel::-webkit-scrollbar-track { background: transparent; }
#bd-panel::-webkit-scrollbar-thumb { background: rgba(61, 56, 50, 0.5); border-radius: 2px; }

/* Header */
.bd-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 16px;
  border-bottom: 1px solid rgba(61, 56, 50, 0.4);
  position: sticky;
  top: 0;
  z-index: 10;
  background: rgba(26, 24, 20, 0.95);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-radius: 16px 16px 0 0;
  cursor: grab;
  user-select: none;
}
.bd-header:active { cursor: grabbing; }

.bd-logo {
  width: 20px;
  height: 20px;
  filter: brightness(0) invert(1);
}

.bd-title {
  font-family: 'Fraunces', Georgia, serif;
  font-size: 14px;
  font-weight: 700;
  flex: 1;
  color: #e8e4dc;
  text-decoration: none;
}
.bd-title:hover { color: #2bdcd2; }

.bd-btn {
  background: none;
  border: none;
  color: #e8e4dc;
  opacity: 0.4;
  cursor: pointer;
  padding: 4px;
  border-radius: 4px;
  display: flex;
  align-items: center;
  transition: opacity 0.15s, color 0.15s;
}

.bd-btn:hover { opacity: 0.9; color: #2bdcd2; }
.bd-btn.spinning svg { animation: bd-spin 0.6s linear infinite; }

/* Body */
.bd-body { padding: 16px; }

/* Loading */
.bd-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  padding: 24px 0;
}

.bd-spinner {
  width: 24px;
  height: 24px;
  border: 2px solid rgba(61, 56, 50, 0.4);
  border-top-color: #2bdcd2;
  border-radius: 50%;
  animation: bd-spin 0.8s linear infinite;
}

.bd-status-text {
  font-family: 'Fraunces', Georgia, serif;
  font-size: 12px;
  font-style: italic;
  opacity: 0.5;
}

@keyframes bd-spin { to { transform: rotate(360deg); } }
@keyframes bd-fade-in { from { opacity: 0; } to { opacity: 1; } }

/* Error */
.bd-error { text-align: center; padding: 16px 0; }
.bd-error-text { color: #fbbf24; margin-bottom: 12px; font-size: 13px; }

.bd-retry-btn {
  font-family: 'Fraunces', Georgia, serif;
  font-weight: 700;
  background: #2bdcd2;
  color: #0c0c0c;
  border: none;
  padding: 8px 16px;
  border-radius: 8px;
  font-size: 13px;
  cursor: pointer;
}
.bd-retry-btn:hover { opacity: 0.9; }

/* Verdict */
.bd-result { animation: bd-fade-in 0.3s ease-in forwards; }

.bd-verdict {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 12px;
  border-radius: 10px;
  background: rgba(23, 23, 23, 0.5);
  border: 1px solid rgba(61, 56, 50, 0.3);
}

.bd-verdict-icon { font-size: 28px; line-height: 1; flex-shrink: 0; }
.bd-verdict-body { flex: 1; min-width: 0; }
.bd-verdict-reason { font-size: 13px; line-height: 1.5; }

.bd-verdict-sources {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 8px;
}

.bd-verdict-sources a {
  font-size: 11px;
  color: #2bdcd2;
  opacity: 0.8;
  text-decoration: underline;
  text-underline-offset: 0.15em;
  text-decoration-thickness: 1px;
}
.bd-verdict-sources a:hover { opacity: 1; }

/* Alternatives */
.bd-alternatives { margin-top: 16px; }
.bd-alternatives h2 {
  font-family: 'Fraunces', Georgia, serif;
  font-size: 14px;
  font-weight: 700;
  margin-bottom: 10px;
}

.bd-alt-card {
  background: rgba(23, 23, 23, 0.5);
  border: 1px solid rgba(61, 56, 50, 0.3);
  border-radius: 10px;
  margin-bottom: 10px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  animation: bd-fade-in 0.3s ease-in forwards;
}

.bd-alt-card img {
  width: 100%;
  height: 120px;
  object-fit: contain;
  background: #252220;
  border-bottom: 1px solid rgba(61, 56, 50, 0.4);
}

.bd-img-placeholder {
  width: 100%;
  height: 120px;
  background: #252220;
  border-bottom: 1px solid rgba(61, 56, 50, 0.4);
}

.bd-alt-info { padding: 12px; }

.bd-alt-name {
  font-family: 'Fraunces', Georgia, serif;
  font-size: 13px;
  font-weight: 700;
  margin-bottom: 4px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}

.bd-alt-name a {
  color: inherit;
  text-decoration: underline;
  text-underline-offset: 0.15em;
  text-decoration-thickness: 1.5px;
}
.bd-alt-name a:hover { color: #2bdcd2; }

.bd-alt-price {
  font-size: 12px;
  color: #2bdcd2;
  font-weight: 800;
  margin-bottom: 4px;
}

.bd-alt-pros, .bd-alt-cons {
  font-size: 11px;
  line-height: 1.6;
  opacity: 0.8;
}
.bd-alt-pros .bd-icon { color: #34d399; }
.bd-alt-cons .bd-icon { color: #fbbf24; }

.bd-label {
  font-weight: 700;
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 0.03em;
}
.bd-alt-pros .bd-label { color: #34d399; }
.bd-alt-cons .bd-label { color: #fbbf24; }

.bd-amazon-link {
  display: inline-block;
  margin-top: 8px;
  font-family: 'Fraunces', Georgia, serif;
  font-weight: 700;
  font-size: 11px;
  color: #0c0c0c;
  background: #2bdcd2;
  border-radius: 8px;
  padding: 5px 12px;
  text-decoration: none;
  transition: opacity 0.15s;
}
.bd-amazon-link:hover { opacity: 0.85; }

/* Mini verdict badge in header */
.bd-mini-verdict {
  display: none;
  font-size: 16px;
  line-height: 1;
}

/* Minimized state */
#bd-panel.bd-minimized .bd-body { display: none; }
#bd-panel.bd-minimized {
  max-height: none;
  overflow: hidden;
}
#bd-panel.bd-minimized .bd-header {
  border-bottom: none;
  border-radius: 16px;
}
#bd-panel.bd-minimized .bd-mini-verdict { display: inline; }

/* More options button */
.bd-more-btn {
  display: block;
  width: 100%;
  margin-top: 10px;
  font-family: 'Fraunces', Georgia, serif;
  font-weight: 700;
  font-size: 12px;
  color: #e8e4dc;
  background: rgba(43, 220, 210, 0.1);
  border: 1px solid rgba(43, 220, 210, 0.25);
  border-radius: 8px;
  padding: 8px 16px;
  cursor: pointer;
  transition: background 0.15s, border-color 0.15s;
}
.bd-more-btn:hover { background: rgba(43, 220, 210, 0.2); border-color: rgba(43, 220, 210, 0.4); }
.bd-more-btn[disabled] { opacity: 0.5; cursor: default; }

/* Go Diving button */
.bd-go-btn {
  font-family: 'Fraunces', Georgia, serif;
  font-weight: 700;
  font-size: 14px;
  background: #2bdcd2;
  color: #0c0c0c;
  border: none;
  padding: 10px 24px;
  border-radius: 8px;
  cursor: pointer;
  transition: opacity 0.15s;
}
.bd-go-btn:hover { opacity: 0.9; }
`,G="bindiving-20",O=24*60*60*1e3,F='<svg class="bd-icon" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>',D='<svg class="bd-icon" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/></svg>',j='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M1 4v6h6"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>',C='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/></svg>',k='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h6v6"/><path d="M9 21H3v-6"/><path d="M21 3l-7 7"/><path d="M3 21l7-7"/></svg>',R='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18"/><path d="M6 6l12 12"/></svg>',Y=chrome.runtime.getURL("icons/favicon.svg");function S(){var n,r;const e=window.location.pathname.match(/\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Z0-9]{10})/);if(e)return e[1];const t=document.querySelector('link[rel="canonical"]');return((r=(n=t==null?void 0:t.href)==null?void 0:n.match(/\/dp\/([A-Z0-9]{10})/))==null?void 0:r[1])??void 0}function E(){var e,t;return((t=(e=document.getElementById("productTitle"))==null?void 0:e.textContent)==null?void 0:t.trim())||void 0}function z(){var r,a;const e=document.querySelector(".a-price .a-price-whole"),t=document.querySelector(".a-price .a-price-fraction");if(e!=null&&e.textContent){const d=e.textContent.trim().replace(/[.,]$/,""),o=((r=t==null?void 0:t.textContent)==null?void 0:r.trim())||"00";return`$${d}.${o}`}const n=document.getElementById("priceblock_dealprice")||document.getElementById("priceblock_ourprice")||document.querySelector("#corePrice_feature_div .a-offscreen");return((a=n==null?void 0:n.textContent)==null?void 0:a.trim())||void 0}function L(){var t,n;const e=document.querySelectorAll("#wayfinding-breadcrumbs_feature_div li a");if(e.length>0)return((n=(t=e[e.length-1])==null?void 0:t.textContent)==null?void 0:n.trim())||void 0}function _(){const e=document.title;if(!e)return null;let t=e.replace(/\s*[-–—|:]\s*Amazon\.\w+(\.\w+)?$/i,"").replace(/^Amazon\.\w+(\.\w+)?\s*[:|-–—]\s*/i,"").trim();const n=t.split(/\s*:\s*/);return n.length>1&&(t=n[0].trim()),t.length>3?t:null}async function U(e){try{const n=(await chrome.storage.local.get(e))[e];return n?Date.now()-n.timestamp>O?(chrome.storage.local.remove(e),null):n:null}catch{return null}}async function M(e,t,n){try{await chrome.storage.local.set({[e]:{result:t,resolvedAlts:n,timestamp:Date.now()}})}catch{}}let p=null,i=null,b=!1,f=null,g=[];function V(){if(p&&i)return{root:i,container:i.getElementById("bd-panel")};p=document.createElement("div"),p.id="bindiving-host",i=p.attachShadow({mode:"closed"});const e=document.createElement("style");e.textContent=$,i.appendChild(e);const t=document.createElement("div");t.id="bd-panel",t.innerHTML=`
    <div class="bd-header">
      <img class="bd-logo" src="${Y}" alt="">
      <a class="bd-title" href="https://bindiving.com" target="_blank" rel="noopener">Bin Diving</a>
      <span class="bd-mini-verdict"></span>
      <button class="bd-btn bd-redive" title="Re-dive">${j}</button>
      <button class="bd-btn bd-minimize" title="Minimize">${C}</button>
      <button class="bd-btn bd-close" title="Close">${R}</button>
    </div>
    <div class="bd-body">
      <div class="bd-state bd-loading">
        <div class="bd-spinner"></div>
        <p class="bd-status-text">Diving in...</p>
      </div>
      <div class="bd-state bd-error" style="display:none">
        <p class="bd-error-text"></p>
        <button class="bd-retry-btn">Try again</button>
      </div>
      <div class="bd-state bd-result" style="display:none">
        <div class="bd-verdict">
          <div class="bd-verdict-icon"></div>
          <div class="bd-verdict-body">
            <p class="bd-verdict-reason"></p>
            <div class="bd-verdict-sources"></div>
          </div>
        </div>
        <div class="bd-alternatives" style="display:none">
          <h2>Better options</h2>
          <div class="bd-alt-list"></div>
          <button class="bd-more-btn" style="display:none">Give me more options</button>
        </div>
      </div>
    </div>
  `,i.appendChild(t),document.body.appendChild(p),i.querySelector(".bd-close").addEventListener("click",I),i.querySelector(".bd-redive").addEventListener("click",()=>{const s=i.querySelector(".bd-redive");s.classList.add("spinning"),x(!0).finally(()=>s.classList.remove("spinning"))}),i.querySelector(".bd-retry-btn").addEventListener("click",()=>x(!0)),i.querySelector(".bd-minimize").addEventListener("click",X),i.querySelector(".bd-more-btn").addEventListener("click",K);let n=0,r=0,a=0,d=0,o=!1;const c=i.querySelector(".bd-header");return c.addEventListener("pointerdown",s=>{if(s.target.closest(".bd-btn"))return;o=!0,n=s.clientX,r=s.clientY;const l=t.getBoundingClientRect();a=l.left,d=l.top,c.setPointerCapture(s.pointerId),t.style.transition="none"}),c.addEventListener("pointermove",s=>{if(!o)return;const l=s.clientX-n,W=s.clientY-r;let y=a+l,v=d+W;const J=t.offsetWidth,Q=t.offsetHeight;y=Math.max(0,Math.min(window.innerWidth-J,y)),v=Math.max(0,Math.min(window.innerHeight-Q,v)),t.style.left=`${y}px`,t.style.top=`${v}px`,t.style.right="auto"}),c.addEventListener("pointerup",s=>{o&&(o=!1,t.style.transition="",c.releasePointerCapture(s.pointerId),chrome.storage.local.set({_panelPos:{left:t.style.left,top:t.style.top}}))}),chrome.storage.local.get(["_panelPos","_minimized"]).then(s=>{if(s._panelPos&&(t.style.left=s._panelPos.left,t.style.top=s._panelPos.top,t.style.right="auto"),s._minimized){b=!0,t.classList.add("bd-minimized");const l=i.querySelector(".bd-minimize");l.innerHTML=k,l.setAttribute("title","Expand")}}),{root:i,container:t}}function X(){if(!i)return;const e=i.getElementById("bd-panel"),t=i.querySelector(".bd-minimize"),n=i.querySelector(".bd-mini-verdict");b=!b,b?(e.classList.add("bd-minimized"),t.innerHTML=k,t.setAttribute("title","Expand"),f&&(n.textContent=f.verdict==="up"?"👍":"👎")):(e.classList.remove("bd-minimized"),t.innerHTML=C,t.setAttribute("title","Minimize"),n.textContent=""),chrome.storage.local.set({_minimized:b})}function q(){const{container:e}=V();e.classList.add("bd-visible"),chrome.storage.local.set({_panelOpen:!0})}function I(){var e;i&&((e=i.getElementById("bd-panel"))==null||e.classList.remove("bd-visible")),chrome.storage.local.set({_panelOpen:!1})}function Z(){var e;return((e=i==null?void 0:i.getElementById("bd-panel"))==null?void 0:e.classList.contains("bd-visible"))??!1}function u(e){i&&(i.querySelectorAll(".bd-state").forEach(t=>{t.style.display="none"}),i.querySelector(`.bd-${e}`).style.display="")}function N(e){const t=document.createElement("div");return t.textContent=e,t.innerHTML}function P(e){if(!i)return;u("result"),f={verdict:e.verdict,reason:e.reason},i.querySelector(".bd-verdict-icon").textContent=e.verdict==="up"?"👍":"👎",i.querySelector(".bd-verdict-reason").textContent=e.reason;const t=i.querySelector(".bd-verdict-sources");t.innerHTML="",e.sources.length>0?(e.sources.forEach(n=>{const r=document.createElement("a");r.href=n,r.target="_blank",r.rel="noopener";try{r.textContent=new URL(n).hostname.replace(/^www\./,"")}catch{r.textContent=n}t.appendChild(r)}),t.style.display=""):t.style.display="none"}function A(e,t){if(i&&(P(e),e.verdict==="down"&&e.alternatives.length>0)){const n=i.querySelector(".bd-alternatives");n.style.display="";const r=i.querySelector(".bd-alt-list");r.innerHTML="",g=[...e.alternatives],e.alternatives.forEach((d,o)=>{const c=B(d);r.appendChild(c);const s=t==null?void 0:t[o];s?h(c,s):m(d).then(l=>{l&&h(c,l)})});const a=i.querySelector(".bd-more-btn");a.style.display=""}}function K(){if(!i)return;const e=i.querySelector(".bd-more-btn");e.textContent="Loading...",e.setAttribute("disabled","");const t=E()||_();if(!t)return;const n=g.map(a=>a.product_name),r={product_name:t,price:z(),category:L(),asin:S()||void 0,exclude_products:n};w(r,{onResult(a){if(!i)return;const d=i.querySelector(".bd-alt-list"),o=a.alternatives.filter(c=>!n.some(s=>s.toLowerCase()===c.product_name.toLowerCase()));o.forEach(c=>{g.push(c);const s=B(c);d.appendChild(s),m(c).then(l=>{l&&h(s,l)})}),e.textContent="Give me more options",e.removeAttribute("disabled"),o.length===0&&(e.textContent="No more options found",setTimeout(()=>{e.textContent="Give me more options"},2e3))},onError(){e.textContent="Give me more options",e.removeAttribute("disabled")}})}function B(e){const t=document.createElement("div");t.className="bd-alt-card";const n=document.createElement("div");n.className="bd-img-placeholder",t.appendChild(n);const r=document.createElement("div");r.className="bd-alt-info",r.style.width="100%";const a=document.createElement("div");if(a.className="bd-alt-name",a.textContent=e.product_name,r.appendChild(a),e.price){const d=document.createElement("div");d.className="bd-alt-price",d.textContent=e.price,r.appendChild(d)}if(e.pros.length>0){const d=document.createElement("div");d.className="bd-alt-pros",d.innerHTML='<span class="bd-label">Pros</span><br>'+e.pros.map(o=>`${F} ${N(o)}`).join("<br>"),r.appendChild(d)}if(e.cons.length>0){const d=document.createElement("div");d.className="bd-alt-cons",d.innerHTML='<span class="bd-label">Cons</span><br>'+e.cons.map(o=>`${D} ${N(o)}`).join("<br>"),r.appendChild(d)}return t.appendChild(r),t}function h(e,t){const n=e.querySelector(".bd-img-placeholder");if(n&&t.image_url){const a=document.createElement("img");a.src=t.image_url,a.alt=t.product_name,n.replaceWith(a)}const r=t.amazon_url||(t.amazon_id?`https://www.amazon.com/dp/${t.amazon_id}/?tag=${G}`:null);if(r){const a=e.querySelector(".bd-alt-name");if(a&&!a.querySelector("a")){const o=document.createElement("a");o.href=r,o.target="_blank",o.rel="noopener",o.textContent=a.textContent||"",a.textContent="",a.appendChild(o)}const d=e.querySelector(".bd-alt-info");if(d&&!d.querySelector(".bd-amazon-link")){const o=document.createElement("a");o.className="bd-amazon-link",o.href=r,o.target="_blank",o.rel="noopener",o.textContent="View on Amazon",d.appendChild(o)}}if(t.price){const a=e.querySelector(".bd-alt-price");if(a)a.textContent=t.price;else{const d=e.querySelector(".bd-alt-info"),o=document.createElement("div");o.className="bd-alt-price",o.textContent=t.price;const c=d==null?void 0:d.querySelector(".bd-alt-name");c==null||c.after(o)}}}async function x(e=!1,t=!1){t||q(),u("loading");const n=S(),r=E()||_();if(!r){i&&(i.querySelector(".bd-error-text").textContent="Could not detect a product on this page.",u("error"));return}const a=n||r.toLowerCase().replace(/\s+/g,"-").slice(0,60);if(!e){const o=await U(a);if(o){A(o.result,o.resolvedAlts);return}}const d={product_name:r,price:z(),category:L(),asin:n||void 0};w(d,{onStatus(o){i&&(i.querySelector(".bd-status-text").textContent=o)},onVerdict(o){P(o)},onResult(o){A(o),o.alternatives.length>0?Promise.all(o.alternatives.map(c=>m(c))).then(c=>{M(a,o,c)}):M(a,o,[])},onError(o){i&&(i.querySelector(".bd-error-text").textContent=o,u("error"))}})}function T(){return/\/(?:dp|gp\/product|gp\/aw\/d)\/[A-Z0-9]{10}/.test(window.location.pathname)||!!document.getElementById("productTitle")}function H(){if(q(),!i)return;u("loading");const e=i.querySelector(".bd-status-text");e.textContent="";const t=i.querySelector(".bd-spinner");t.style.display="none";const n=document.createElement("button");n.className="bd-go-btn",n.textContent="Go Diving",n.addEventListener("click",()=>{n.remove(),t.style.display="",x(!1,!0)}),i.querySelector(".bd-loading").appendChild(n)}chrome.runtime.onMessage.addListener(e=>{if(e.type==="TOGGLE_PANEL"){if(!T())return;Z()?I():H()}}),T()&&chrome.storage.local.get("_panelOpen").then(e=>{e._panelOpen&&H()})})();
